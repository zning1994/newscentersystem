<?php
	define('THINK_PATH','./ThinkPHP/');
	define('APP_PATH','./admin/');
	define('APP_NAME','admin');
	define('APP_DEBUG',true);

	require	THINK_PATH.'ThinkPHP.php';
?>