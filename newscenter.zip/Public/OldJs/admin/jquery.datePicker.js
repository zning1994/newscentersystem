<?xml version="1.0" encoding="UTF-8"?>
<Error>
<Code>AccessDenied</Code>
<Message>Access Denied</Message>
<RequestId>B0A834B9BACC1D39</RequestId>
<HostId>K6JlnOIIb1tJDvqdj8NITAsbd+ZO6hJmi4cxkIMy8R3cdI+h5WCF7y6iHwBEQkIN</HostId>
</Error>