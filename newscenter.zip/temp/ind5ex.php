<?php
	
	define('THINK_PATH','./ThinkPHP/');
	define('APP_PATH','./admin/');
	define('APP_NAME','admin');
	define('STRIP_RUNTIME_SPACE',false);
	define('APP_DEBUG',true);
	define('__PUBLIC__','__ROOT__/public/');

	require		THINK_PATH.'ThinkPHP.php';

?>