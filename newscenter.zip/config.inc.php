<?php 
return array(
	'DB_TYPE'			=>	'mysql',
	'DB_HOST'			=>	'localhost',
	'DB_NAME'			=>	'think',
	'DB_USER'			=>	'root',
	'DB_PWD'			=>	'',//7erG3zKmV8sKMKQ4
	'DB_PORT'			=>	'3306',
	'DB_PREFIX'		=>	'think_',
);
?>