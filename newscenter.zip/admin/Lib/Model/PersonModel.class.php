<?php
/*
 * 自定义Person模型类
 * 功能：1.完成自动验证功能
 */

//注意：自动验证需要根据自身情况来使用，ThinkPHP为我们封装一个成员属性，
//CREATE的时候,内部会自动去找这些自动验证方法
class PersonModel extends Model{
	
	
	
	
}

?>